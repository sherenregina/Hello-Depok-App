package com.example.hellodepokapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_search.*
import java.util.*
import kotlin.collections.ArrayList

class search : AppCompatActivity() {

    val arrayList = ArrayList<model>()
    val displayList = ArrayList<model>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)


        arrayList.add(model(" Wisata Alam Kampung 99 Pepohonan", "Lokasi: Jl. KH. Muhasan II, Meruyung, Kec. Limo, Depok, Jawa Barat.", R.drawable.kampung99))
        arrayList.add(model("Masjid Kubah Emas", "Lokasi: Meruyung, Kec. Limo, Depok, Jawa Barat", R.drawable.kubahmas))
        arrayList.add(model("GodongIjo Depok", "Lokasi: Jl. Cinangka Raya KM 10 No. 60, Serua, Kec. Bojongsari, Depok, Jawa Barat.", R.drawable.godong))
        arrayList.add(model("Agrowisata Belimbing Dewa Depok", "Lokasi: Kel. Pasir Putih, Kec. Sawangan, Depok, Jawa Barat", R.drawable.belimbing))
        arrayList.add(model("Hutan Kota Depok", "Lokasi: Srengseng Sawah, Kec. Jagakarsa, Depok, Jawa Barat", R.drawable.hutan))
        arrayList.add(model("D’Kandang Amazing Farm Depok", "Lokasi: Jl. Penarikan, Pasir Putih, Kec. Sawangan, Depok, Jawa Barat.", R.drawable.kandang))
        arrayList.add(model("Setu Pengasinan Depok", "Lokasi: Jl. Utomo No. 19-22, Pengasinan, Kec. Sawangan, Depok, Jawa Barat", R.drawable.setu))
        arrayList.add(model("Studio Alam TVRI Depok", "Lokasi: Jl. Abdul Ghani, Kel. Kalibaru, Kec. Cilodong, Depok, Jawa Barat.", R.drawable.studio))
        arrayList.add(model("Taman Lembah Gurame", "Lokasi: Jl. Nangka Raya No. 68, Depok Jaya, Kec. Pancoran Mas, Depok, Jawa Barat.", R.drawable.gurame))
        displayList.addAll(arrayList)

        val myAdapter = MyAdapter(displayList, this)

        recyclerview.layoutManager = LinearLayoutManager(this)
        recyclerview.adapter = myAdapter
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        menuInflater.inflate(R.menu.menu1, menu)
        val menuItem = menu!!.findItem(R.id.search1)

        if (menuItem != null){

            val searchView = menuItem.actionView as SearchView

            val editText = searchView.findViewById<EditText>(androidx.appcompat.R.id.search_src_text)
            editText.hint = "Search..."

            searchView.setOnQueryTextListener(object  : SearchView.OnQueryTextListener{
                override fun onQueryTextSubmit(query: String?): Boolean {
                    return true
                }

                override fun onQueryTextChange(newText: String?): Boolean {

                    if (newText!!.isNotEmpty()){
                        displayList.clear()
                        val search = newText.toLowerCase(Locale.getDefault())
                        arrayList.forEach{

                            if (it.title.toLowerCase(Locale.getDefault()).contains(search)){
                                displayList.add(it)
                            }
                        }
                        recyclerview.adapter!!.notifyDataSetChanged()
                    }
                    else{

                        displayList.clear()
                        displayList.addAll(arrayList)
                        recyclerview.adapter!!.notifyDataSetChanged()
                    }

                    return true
                }

            })
        }

        return super.onCreateOptionsMenu(menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        return super.onContextItemSelected(item)
    }
}
