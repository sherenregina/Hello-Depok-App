package com.example.hellodepokapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_attraction.*

class attraction : AppCompatActivity() {

    val emergencyNumber = arrayOf("Emergency Call Depok : 112","Polres Metro Depok : 0217520014","Pemadam Kebakaran : 02177212004","Pengaduan Lampu PJU : 02187900083","samsat : 021 778 22270","Indihome : 147","RS Mitra Keluarga : 02177210700","Dinas Kebersihan & Pertamanan : 02177834688","Kejaksaaan : 021-752 0883","Gangguan PLN : 021-778 24057","Kantor Pajak Depok : 021 7720 3892","Kodim 0508 : 021 775 2823")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_attraction)

        val arrayAdapter = ArrayAdapter (this@attraction,android.R.layout.simple_spinner_dropdown_item,
            emergencyNumber)
        spinner.adapter = arrayAdapter
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {

            }

        }
    }
}
