package com.example.hellodepokapp.Model

class Post {
    private var reportid: String = ""
    private var postimage: String = ""
    private var publisher: String = ""
    private var description: String = ""

    constructor()


    constructor(reportid: String, postimage: String, publisher: String, description: String) {
        this.reportid = reportid
        this.postimage = postimage
        this.publisher = publisher
        this.description = description
    }

    fun getReportid(): String{
        return reportid
    }

    fun getPostimage(): String{
        return postimage
    }

    fun getPublisher(): String{
        return publisher
    }

    fun getDescription(): String{
        return description
    }

    fun setReportid(reportid: String){
        this.reportid = reportid
    }

    fun setPostimage(postimage: String){
        this.postimage = postimage
    }

    fun setPublisher(publisher: String){
        this.publisher = publisher
    }

    fun setDescription(description: String){
        this.description = description
    }
}