package com.example.hellodepokapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Detail2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail2)
    }
}
