package com.example.hellodepokapp

class model (val title:String, val des:String, val image:Int){
}