package com.example.hellodepokapp.Model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class News (
    var desc:String ?= "",
    var publisher:String ?= "",
    var waktu:String ?= "",
    var judul:String ?= "",
    var poster:String ?= ""
): Parcelable