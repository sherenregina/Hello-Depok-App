package com.example.hellodepokapp.Fragments


import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.hellodepokapp.*

import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.fragment_home.view.*

/**
 * A simple [Fragment] subclass.
 */
class HomeFragment : Fragment() {

    private lateinit var auth : FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        view.btnemc.setOnClickListener{
            startActivity(Intent(context,attraction::class.java))
        }
        view.btnmjr.setOnClickListener{
            startActivity(Intent(context,major::class.java))
        }
        view.btninf.setOnClickListener{
            startActivity(Intent(context,depok::class.java))
        }
        view.btnmsc.setOnClickListener{
            startActivity(Intent(context,music::class.java))
        }
        view.imageButton2.setOnClickListener {
            startActivity(Intent(context,MapsActivity::class.java))
        }
        view.btnatt.setOnClickListener{
            startActivity(Intent(context,search::class.java))
        }
        return view
    }

}
