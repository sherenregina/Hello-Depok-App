package com.example.hellodepokapp.onboarding

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.hellodepokapp.MainActivity
import com.example.hellodepokapp.R
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_getstarted.*

class getstarted : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_getstarted)

        auth = FirebaseAuth.getInstance()

        btn_started.setOnClickListener {
            var intent = Intent(this@getstarted, signin::class.java)
            startActivity(intent)
            finish()
        }
        button4.setOnClickListener {
            var intent = Intent(this@getstarted, signup::class.java)
            startActivity(intent)
            finish()
        }
    }
    override fun onStart() {
        super.onStart()
        if(auth.currentUser != null){
            Intent(this@getstarted, MainActivity::class.java).also{ intent ->
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
            }
        }
    }
}
