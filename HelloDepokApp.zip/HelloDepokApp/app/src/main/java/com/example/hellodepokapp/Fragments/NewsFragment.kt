package com.example.hellodepokapp.Fragments


import android.content.Intent
import android.os.Bundle
import android.preference.Preference
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.hellodepokapp.Adapter.EditorChoiceAdapter
import com.example.hellodepokapp.Adapter.MostInterestedAdapter
import com.example.hellodepokapp.DetailActivity
import com.example.hellodepokapp.Model.News

import com.example.hellodepokapp.R
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.fragment_news.*
import java.util.prefs.Preferences

/**
 * A simple [Fragment] subclass.
 */
class NewsFragment : Fragment() {


    private lateinit var mDatabase : DatabaseReference

    private var dataList = ArrayList<News>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_news, container, false)
    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)


        mDatabase = FirebaseDatabase.getInstance().getReference("News")

        rv_most_interested.layoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        rv_editor_choice.layoutManager = LinearLayoutManager(context)

        getData()
    }

    private fun getData() {
        mDatabase.addValueEventListener(object : ValueEventListener {
            override fun onCancelled(databaseError: DatabaseError) {
                Toast.makeText(context, ""+databaseError.message, Toast.LENGTH_LONG).show()
            }

            override fun onDataChange(dataSnapshot: DataSnapshot) {

                dataList.clear()
                for (getdataSnapshot in dataSnapshot.children){
                    var news = getdataSnapshot.getValue(News::class.java)
                    dataList.add(news!!)
                }

                rv_most_interested.adapter = MostInterestedAdapter(dataList){
                    var intent = Intent(context, DetailActivity::class.java).putExtra("data", it)
                    startActivity(intent)
                }

                rv_editor_choice.adapter = EditorChoiceAdapter(dataList){
                    var intent = Intent(context, DetailActivity::class.java).putExtra("data", it)
                    startActivity(intent)
                }

            }
        })
    }


}
