package com.example.hellodepokapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.hellodepokapp.Model.News
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val data = intent.getParcelableExtra<News>("data")

        tv_title.text = data?.judul
        tv_uploader.text = data?.publisher
        tv_hour.text = data?.waktu
        tv_content.text = data?.desc

        Glide.with(this)
            .load(data?.poster)
            .into(iv_poster)
    }
}


